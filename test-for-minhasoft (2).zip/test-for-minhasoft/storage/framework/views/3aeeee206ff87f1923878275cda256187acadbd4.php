

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-12" style="text-align:right">
            <button style="text-align:right" class="btn btn-primary" onclick="exportToPdf()">Export To PDF</button>
            <a href="/consignments/create" style="text-align:right" class="btn btn-primary">Add</a>
        </div>
    </div>
    <div class="mt-2 row justify-content-center">
        <div class="col-md-12">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Company</th>
                        <th>Contact</th>
                        <th>Address Line 1</th>
                        <th>Address Line 2</th>
                        <th>Address Line 3</th>
                        <th>City</th>
                        <th>Country</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($consignment) > 0): ?>
                        <?php $__currentLoopData = $consignment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($con->company ? $con->company : ''); ?></td>
                            <td><?php echo e($con->contact? $con->contact : ''); ?></td>
                            <td><?php echo e($con->address_line_1 ? $con->address_line_1 : ''); ?></td>
                            <td><?php echo e($con->address_line_2 ? $con->address_line_2 : ''); ?></td>
                            <td><?php echo e($con->address_line_3 ? $con->address_line_3 : ''); ?></td>
                            <td><?php echo e($con->city ? $con->city : ''); ?></td>
                            <td><?php echo e($con->country ? $con->country : ''); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>



<script>
    function exportToPdf() {
        window.location.href = '/consignments/export';
    }
</script>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\test-for-minhasoft\resources\views/consignment/index.blade.php ENDPATH**/ ?>