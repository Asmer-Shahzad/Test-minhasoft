<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consignments PDF</title>
</head>
<body>
    <h1>Consignments</h1>
    <table border="1">
        <thead>
            <tr>
                <th>Company</th>
                <th>Contact</th>
                <th>Address Line 1</th>
                <th>Address Line 2</th>
                <th>Address Line 3</th>
                <th>City</th>
                <th>Country</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $consignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($consignment->company ? $consignment->company  : ''); ?></td>
                    <td><?php echo e($consignment->contact ? $consignment->contact : ''); ?></td>
                    <td><?php echo e($consignment->address_line_1 ? $consignment->address_line_1: ''); ?></td>
                    <td><?php echo e($consignment->address_line_2 ?$consignment->address_line_2 : ''); ?></td>
                    <td><?php echo e($consignment->address_line_3 ?$consignment->address_line_3  : ''); ?></td>
                    <td><?php echo e($consignment->city ? $consignment->city : ''); ?></td>
                    <td><?php echo e($consignment->country ?$consignment->country : ''); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH C:\laragon\www\test-for-minhasoft\resources\views/consignment/export.blade.php ENDPATH**/ ?>